#!/bin/bash
clear
echo -e " ---------------------------------"
echo -e "  MCI Password Manager Pro script "
echo -e " ---------------------------------"
echo -e "Script started.\n"

PMP_IP="10.20.25.43"
ADDED_TO_SUDOER="pmp ALL=(ALL) NOPASSWD : /usr/bin/passwd"

echo -e "****************Please Note***************"
echo -e "Before running this script you should:\n"
echo -e "1.route to Password Manager Pro IP : $PMP_IP \n"
echo -e "2.install SUDO package \n "
echo -e " * Linux : from repository \n "
echo -e " ** SunOS : from http://www.sudo.ws/sudo/download.html \n"
echo -e "******************************************\n"

read -p "Are you sure to continue ?(y:yes)  " -n 1 -r
echo -e "\n\n"
if [[ ! $REPLY =~ ^[Yy]$ ]]
	then
		exit 1
fi

if ([ ! -f /usr/bin/sudo ] && [ ! -f /usr/local/bin/sudo ]); then
	echo -e "ERROR: sudo package is not installed yet."
	echo -e "\n\n"
	echo -e "*********script finished unsuccessfully*********"
	exit 1
fi 

if [ ! -f /tmp/pmp-configuration/pmp_rsa.pub ]; then
	echo -e "ERROR: public key file not found."
	echo -e "maybe pmp configuration is not extracted correctly."
	echo -e "\n\n"
	echo -e "*********script finished unsuccessfully*********"
	exit 1
fi 

echo -e " Checking Installed OS ... "
DETECTEDOS=`uname`

if [ "$DETECTEDOS" == "SunOS" ]
 then
	echo -e " Installed OS is SunOS \n\n"
	echo -e "*********Procedure For SunOS System is started***********"
	echo -e "4 steps should be done successfully .\n "
	echo -e "step 1. Adding pmp user ... "
	if [ ! -z "$(getent passwd pmp)" ]; then
		echo -e "ERROR: user already exists.\nPlease delete it manually.\n(edit /etc/passwd and /etc/shadow)"
		echo -e "\n\n"
		echo -e "*********script finished unsuccessfully*********\n"
		exit 1
	fi
	if [ ! -z "$(getent group pmp)" ]; then
		echo -e "ERROR: user group already exists.\nPlease delete it manually.\n(edit /etc/group)"
		echo -e "\n\n"
		echo -e "*********script finished unsuccessfully*********\n"
		exit 1
	fi
	groupadd -g 500001 pmp
	chmod u+w /etc/passwd
	cp /etc/passwd  /etc/passwd-orig
	echo pmp:x:500001:500001:It is Password Manager Pro user:/export/home/pmp:/bin/bash >> /etc/passwd
	echo -e "	pmp user is created. \n"
	chmod u+w /etc/shadow
	cp /etc/shadow  /etc/shadow-orig
	echo pmp:saA/2NUr4e5f2:16441:::::: >> /etc/shadow
	echo -e "	pmp password is set. \n"
	if [ ! -d /export/home/pmp ]; then
		mkdir /export/home/pmp
	fi
	usermod -a -G pmp pmp
	echo -e "step 1 is done."


		
	echo -e "\n\n"
	echo -e "step 2. Adding mci user ...\n "
	if [ ! -z "$(getent passwd mci)" ]; then
		echo -e "ERROR: user already exists.\nPlease delete it manually.\n(edit /etc/passwd and /etc/shadow)"
		echo -e "\n\n"
		echo -e "*********script finished unsuccessfully*********\n"
		exit 1
	fi
	chmod u+w /etc/passwd
	cp /etc/passwd /etc/passwd-orig
	echo mci:x:0:0:user only for SPECIAL use:/export/home/mci:/bin/bash >> /etc/passwd
	echo -e "	mci user is created. \n"
	chmod u+w /etc/shadow
	cp /etc/shadow /etc/shadow-orig
	echo mci:N42oIyQ166DSU:16441:::::: >> /etc/shadow
	echo -e "	mci password is set. \n"
	if [ ! -d /export/home/mci ]; then
		mkdir /export/home/mci
	fi
	echo -e "step 2 is done." 

	chmod u-w /etc/passwd
	chmod u-w /etc/shadow

	echo -e "\n\n"
	echo -e "step 3. Copying PKA authentication ... \n "
	if [ ! -d ~pmp/.ssh ]; then
		mkdir ~pmp/.ssh
	fi
	cat  /tmp/pmp-configuration/pmp_rsa.pub > ~pmp/.ssh/authorized_keys
	echo -e " Public key is copied into ~pmp/.ssh/authorized_keys.\n"

	

	echo -e "\n\n"
	echo -e "step 4. Editing Sudoers file and linking sudo command in solaris ...\n"
	cat /etc/sudoers >> /etc/sudoers-origin
	echo $ADDED_TO_SUDOER >> /etc/sudoers
	echo -e "sudoer file is editted.\n"
	if [ ! -f /usr/bin/sudo ]; then
		ln -s /usr/local/bin/sudo /usr/bin/sudo
		echo -e "sudo command is linked. \n"	
	fi
 	echo -e "step 4 finished.\n " 

	

	echo -e " *********Procedure For SunOS System is Finished***********\n"
	echo -e "don't forget to add static route to password manager pro IP : $PMP_IP. \n"
	echo -e "*********script finished successfully*********\n"

	exit 1


 elif [ "$DETECTEDOS" == "Linux" ]
  then
	echo -e " Installed OS is Linux "
	echo -e "*********Procedure For Linux System is started***********"
	echo -e "step 1. Adding pmp user ... "
	if [ ! -z "$(getent passwd pmp)" ]; then
		echo -e "ERROR: user already exists.\n Please delete it manually.\n(edit /etc/passwd and /etc/shadow) "
		echo -e "\n\n"
		echo -e "*********script finished unsuccessfully*********\n"
		exit 1
	fi
	if [ ! -z "$(getent group pmp)" ]; then
		echo -e "ERROR: user group already exists.\nPlease delete it manually.\n(edit /etc/group)"
		echo -e "\n\n"
		echo -e "*********script finished unsuccessfully*********\n"
		exit 1
	fi
	groupadd -g 500001 pmp
	chmod u+w /etc/passwd
	cp /etc/passwd  /etc/passwd-orig
	echo pmp:x:500001:500001:It is Password Manager Pro user:/home/pmp:/bin/bash >> /etc/passwd
	echo -e "	pmp user is created. \n"
	chmod u+w /etc/shadow
	cp /etc/shadow  /etc/shadow-orig
	echo pmp:saA/2NUr4e5f2:16441:::::: >> /etc/shadow
	echo -e "	pmp password is set. \n"
	if [ ! -d /home/pmp ]; then
		mkdir /home/pmp
	fi
	usermod -a -G pmp pmp
	echo -e "step 1 is done."
	


	echo -e "\n\n"
	echo -e "step 2. Adding mci user ...\n "
	if [ ! -z "$(getent passwd mci)" ]; then
		echo -e "user already exists.\nPlease delete it manually.\n(edit /etc/passwd and /etc/shadow) "
		echo -e "\n\n"
		echo -e "script finished unsuccessfully.\n"
		exit 1
	fi
	chmod u+w /etc/passwd
	cp /etc/passwd /etc/passwd-orig
	echo mci:x:0:0:user only for SPECIAL use:/home/mci:/bin/bash >> /etc/passwd
	echo -e "	mci user is created. \n"
	chmod u+w /etc/shadow
	cp /etc/shadow /etc/shadow-orig
	echo mci:N42oIyQ166DSU:16441:::::: >> /etc/shadow
	echo -e "	mci password is set. \n"
	if [ ! -d /home/mci ]; then
		mkdir /home/mci
	fi
	echo -e "step 2 is done." 

	chmod u-w /etc/passwd
	chmod u-w /etc/shadow

	echo -e "\n\n"
	echo -e "step 3. Copying PKA authentication ... \n "
	if [ ! -d ~pmp/.ssh ]; then
		mkdir ~pmp/.ssh
	fi
	cat  /tmp/pmp-configuration/pmp_rsa.pub > ~pmp/.ssh/authorized_keys
	echo -e " Public key is copied into ~pmp/.ssh/authorized_keys.\n"
	echo -e " step 3 is done."
	

	echo -e "\n\n"
	echo -e "step 4. Editing Sudoers file and linking sudo command in solaris ...\n"
	cat /etc/sudoers >> /etc/sudoers-origin
	echo $ADDED_TO_SUDOER >> /etc/sudoers
	echo -e "sudoer file is editted.\n"
	if [ ! -f /usr/bin/sudo ]; then
		ln -s /usr/local/bin/sudo /usr/bin/sudo
		echo -e "sudo command is linked. \n"	
	fi
 	echo -e "step 4 is done."
 
	echo -e " Don't forget to add route to password manager pro IP : $PMP_IP .\n"
	echo -e " *********Procedure For Linux System is Finished***********\n"
	echo -e "  **********  script finished successfully  *********  \n"

	exit 1	
	
 else
	echo -e "The Detected OS is not matched"
	echo -e "\n\n"
	echo -e "script finished unsuccessfully.\n"
	exit 1
fi

